import prompt


def welcome_user():
    NAME = prompt.string("May I have your name? ")
    return NAME


NAME = welcome_user()


if __name__ == "__main__":
    NAME = welcome_user()
    print(f"Hello, {NAME}!")
