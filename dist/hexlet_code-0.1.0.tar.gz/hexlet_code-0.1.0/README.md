### Hexlet tests and linter status:
[![Actions Status](https://github.com/LuybovB/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/LuybovB/python-project-49/actions)

<a href="https://codeclimate.com/github/LuybovB/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/038eb35db103bd0b40f2/maintainability" /></a> 

<a href="https://codeclimate.com/github/LuybovB/python-project-49/test_coverage"><img src="https://api.codeclimate.com/v1/badges/038eb35db103bd0b40f2/test_coverage" /></a>
